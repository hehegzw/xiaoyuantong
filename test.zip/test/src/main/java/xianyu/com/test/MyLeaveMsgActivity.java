package xianyu.com.test;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MyLeaveMsgActivity extends Activity implements View.OnClickListener {

    private TextView contacts_back;
    private ListView my_leave_msg_listview;
    private List<List<LeaveMsg>> list;
    private MyLeaveMsgAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_leave_msg);
        initView();
        setData();
        showList();
    }


    private void showList() {
        adapter = new MyLeaveMsgAdapter(this, list, "1001");
        my_leave_msg_listview.setAdapter(adapter);
    }

    private void setData() {
        list = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            List<LeaveMsg> lists = new ArrayList<>();
            for (int j = 0; j < 7; j++) {
                LeaveMsg contacts = new LeaveMsg();
                contacts.setId(1001 + "");
                contacts.setTime("2015");
                contacts.setContent("hehehehe");
                contacts.setFrom("wo");
                contacts.setTo("you");
                lists.add(contacts);
            }
            list.add(lists);
        }
    }

    private void initView() {
        contacts_back = (TextView) findViewById(R.id.contacts_back);
        my_leave_msg_listview = (ListView) findViewById(R.id.my_leave_msg_listview);
        contacts_back.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        finish();
    }

}
