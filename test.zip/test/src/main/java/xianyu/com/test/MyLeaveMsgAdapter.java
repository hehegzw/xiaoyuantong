package xianyu.com.test;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;



import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by NewOr on 2015/11/27.
 */
public class MyLeaveMsgAdapter extends BaseAdapter {
    private Context context;
    private List<List<LeaveMsg>> list;
    private String username;
    private Map<Integer,Integer> map = new HashMap<>();
    public MyLeaveMsgAdapter(Context context, List<List<LeaveMsg>> list, String username) {
        this.context = context;
        this.list = list;
        this.username = username;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.my_leave_msg_item, null);
            holder = new ViewHolder();
            holder.msg_content = (TextView) convertView.findViewById(R.id.msg_content);
            holder.msg_time = (TextView) convertView.findViewById(R.id.msg_time);
            holder.fromusername = (TextView) convertView.findViewById(R.id.fromusername);
            holder.listView = (ListView) convertView.findViewById(R.id.list);
            holder.reply = (EditText) convertView.findViewById(R.id.reply);
            holder.submit = (TextView) convertView.findViewById(R.id.submit);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }
        holder.msg_content.setText(list.get(position).get(0).getContent());
        holder.fromusername.setText(list.get(position).get(0).getFrom());
        Date date = new Date(Long.valueOf(list.get(position).get(0).getTime()));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
        String str = sdf.format(date);
        holder.msg_time.setText(str);
        initListView(holder,position);

        return convertView;
    }

    private void initListView(final ViewHolder holder, final int position) {
        Log.d("TAG111", "initListView");
        List<LeaveMsg> leaveMsgs = null;
        if(list.get(position).size() > 5){
            leaveMsgs = list.get(position).subList(1,6);
        }else{
            leaveMsgs = list.get(position).subList(1,list.get(position).size());
        }
        final LeaveMsgDetailAtyAdapter adapter = new LeaveMsgDetailAtyAdapter(context,leaveMsgs,username);
        if(list.get(position).size() > 5&&holder.listView.getFooterViewsCount()<1){
            final TextView textView = new TextView(context);
            textView.setText("点击加载全部评论...");
            textView.setTextColor(Color.BLUE);
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (textView.getText().equals("点击加载全部评论...")) {
                        textView.setText("收起");
                        adapter.setList(list.get(position).subList(1, list.get(position).size()));
                        ListViewUtil.setListViewHeightBasedOnChildren(holder.listView);
                    } else {
                        textView.setText("点击加载全部评论...");
                        adapter.setList(list.get(position).subList(1, 6));
                        ListViewUtil.setListViewHeightBasedOnChildren(holder.listView);
                    }
                }
            });
            holder.listView.addFooterView(textView);
        }
        holder.listView.setAdapter(adapter);
        ListViewUtil.setListViewHeightBasedOnChildren(holder.listView);
    }

    private class ViewHolder {
        public TextView msg_time;
        public TextView msg_content;
        public TextView fromusername;
        public ListView listView;
        public EditText reply;
        public TextView submit;
    }

}
